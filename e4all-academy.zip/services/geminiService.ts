
import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getCourseAdvice = async (userMessage: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: userMessage,
      config: {
        systemInstruction: `You are a helpful student advisor for "E4All Academy". 
        The academy offers:
        1. English for Kids (fun, interactive, foundational).
        2. English for Adults (conversation-focused, professional).
        3. IELTS Preparation (strategies for reading, writing, listening, speaking).
        4. Private (One-on-one) or Group sessions.
        
        Always respond in Arabic. Be encouraging and concise. Suggest the best option based on the user's needs.`,
        temperature: 0.7,
      },
    });

    return response.text || "عذراً، لم أستطع فهم طلبك. هل يمكنك المحاولة مرة أخرى؟";
  } catch (error) {
    console.error("Gemini Error:", error);
    return "حدث خطأ في الاتصال بالمستشار الذكي. يرجى المحاولة لاحقاً.";
  }
};
